'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "5aa9675e3354b1008a02df81063aef9d",
"assets/assets/font/SkMobileFont.ttf": "57280535d5ac115504a19b88dca841df",
"assets/assets/image/app/2.0x/logo.png": "acfd1633f5872282c902f04e7b1daf7f",
"assets/assets/image/app/3.0x/logo.png": "1a45285ac5c411ae8a5812aa0ff8f950",
"assets/assets/image/app/app_launch_icon_android.png": "e539a36b5e4bcf5355635ce7ebda1440",
"assets/assets/image/app/app_launch_icon_ios.png": "3697791c2ca86299e7a2c17662c6bf31",
"assets/assets/image/app/favicon.ico": "eafa7d7aabd990ab9f0387c9d973a475",
"assets/assets/image/app/logo.png": "eafdb6d9a0d0a1ca27aef741c26bba87",
"assets/assets/image/app/pwa_apple_icon.png": "18f5040117b62b7074a13b68d507ad04",
"assets/assets/image/app/pwa_icon-192.png": "cd5705c3e27b9db4c40620f7de0af1b8",
"assets/assets/image/app/pwa_icon-512.png": "1cef4d8528e21403c7c7ae45ff3c43c3",
"assets/assets/image/app/splash.png": "09a4f12156b557ec4a4577d62b7cf900",
"assets/assets/image/app/splash_dark.png": "d7dbac1e7e747acbe07fbd030b7dfeae",
"assets/assets/image/common/2.0x/ic_no_image.png": "ab696e3050781cfba503998d81dae1b7",
"assets/assets/image/common/2.0x/ic_switch_to_portrait.png": "f8c1ee94263379b82e3ea60d8cf8d2d4",
"assets/assets/image/common/3.0x/ic_no_image.png": "fccef6c6e08f4bddbcc4b632d21ed6c5",
"assets/assets/image/common/3.0x/ic_switch_to_portrait.png": "62d2bd17f00d22efe72751a5fa8c9dbf",
"assets/assets/image/common/ic_no_image.png": "d05d47ef9be80f1fda6aa154bc98c1c5",
"assets/assets/image/common/ic_switch_to_portrait.png": "c5b7ece88e853f66479535f233049325",
"assets/assets/image/edit/2.0x/ic_avatar_mask.png": "f52f348cc366f7ef5b52862dea65b81a",
"assets/assets/image/edit/3.0x/ic_avatar_mask.png": "41b34e0e747b9f05709f4ee00efc8b3c",
"assets/assets/image/edit/ic_avatar_mask.png": "298e589e64a3417162f16671aa7685d9",
"assets/assets/image/installation_guide/guide_step1_android.png": "f4f86a3dc1ce6b81f6aec6b75871cca7",
"assets/assets/image/installation_guide/guide_step1_ios.png": "fd2ba3c5deaaf846b38b22a8641b8c50",
"assets/assets/image/installation_guide/guide_step2_android.png": "d834a75e72b5b18195f392ad4c90be97",
"assets/assets/image/installation_guide/guide_step2_ios.png": "3e59e0bf40ed2c6c405418c05e103fe1",
"assets/assets/image/login/2.0x/index.jpg": "9044495db467126f737503f2d6b11fb7",
"assets/assets/image/login/3.0x/index.jpg": "0bbd43c582c9b9334683d50529ae5379",
"assets/assets/image/login/index.jpg": "182d967fee1530c6805887b6ace92175",
"assets/assets/image/payment/billing_gateways/billingpaypal.png": "d785e60022ceffa616ffd09d285ab229",
"assets/assets/image/payment/billing_gateways/billingstripe.png": "09f8040821b5e903fdfddabcae0e257a",
"assets/assets/sound/video_im/ring.mp3": "b7cb720e7804796ac8d51bd6db5ca950",
"assets/FontManifest.json": "9ba1f53ac371fb1c31a2252f6dcce7f7",
"assets/fonts/MaterialIcons-Regular.otf": "4e6447691c9509f7acdbf8a931a85ca1",
"assets/NOTICES": "7ea5a98063cf221ec40aeb715285f66f",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_AMS-Regular.ttf": "657a5353a553777e270827bd1630e467",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Caligraphic-Bold.ttf": "a9c8e437146ef63fcd6fae7cf65ca859",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Caligraphic-Regular.ttf": "7ec92adfa4fe03eb8e9bfb60813df1fa",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Fraktur-Bold.ttf": "46b41c4de7a936d099575185a94855c4",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Fraktur-Regular.ttf": "dede6f2c7dad4402fa205644391b3a94",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-Bold.ttf": "9eef86c1f9efa78ab93d41a0551948f7",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-BoldItalic.ttf": "e3c361ea8d1c215805439ce0941a1c8d",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-Italic.ttf": "ac3b1882325add4f148f05db8cafd401",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Main-Regular.ttf": "5a5766c715ee765aa1398997643f1589",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Math-BoldItalic.ttf": "946a26954ab7fbd7ea78df07795a6cbc",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Math-Italic.ttf": "a7732ecb5840a15be39e1eda377bc21d",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_SansSerif-Bold.ttf": "ad0a28f28f736cf4c121bcb0e719b88a",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_SansSerif-Italic.ttf": "d89b80e7bdd57d238eeaa80ed9a1013a",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_SansSerif-Regular.ttf": "b5f967ed9e4933f1c3165a12fe3436df",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Script-Regular.ttf": "55d2dcd4778875a53ff09320a85a5296",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size1-Regular.ttf": "1e6a3368d660edc3a2fbbe72edfeaa85",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size2-Regular.ttf": "959972785387fe35f7d47dbfb0385bc4",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size3-Regular.ttf": "e87212c26bb86c21eb028aba2ac53ec3",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Size4-Regular.ttf": "85554307b465da7eb785fd3ce52ad282",
"assets/packages/flutter_math_fork/lib/katex_fonts/fonts/KaTeX_Typewriter-Regular.ttf": "87f56927f1ba726ce0591955c8b3b42d",
"assets/packages/wakelock_web/assets/no_sleep.js": "7748a45cd593f33280669b29c2c8919a",
"canvaskit/canvaskit.js": "43fa9e17039a625450b6aba93baf521e",
"canvaskit/canvaskit.wasm": "04ed3c745ff1dee16504be01f9623498",
"canvaskit/profiling/canvaskit.js": "f3bfccc993a1e0bfdd3440af60d99df4",
"canvaskit/profiling/canvaskit.wasm": "a9610cf39260f60fbe7524a785c66101",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"firebase-messaging-sw.js": "e713f673924706e1725e06a9a2b55d41",
"firebase-messaging.sw-merge.js": "c31908e7ddf8d4baa8a0c72b16de111e",
"flutter_facebook_auth.js": "6ff57119b80fe9f2fefac6fa756b5dd8",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "3024367bc8cbb9d895a5035692e664b7",
"/": "3024367bc8cbb9d895a5035692e664b7",
"main.dart.js": "b0480bcaa2ac2f2703df6888d5094de0",
"manifest.json": "9d0e086525b150d4416f6b8583132eac",
"orientation.css": "064f284e19912d80240fe15357a03e2a",
"platform.min.js": "24eec2d628fa9153555b311f6fbbbe3f",
"splash.css": "25f8fd2cbc040ef6a25e53cce0f4e470",
"version.json": "151eb5eca3d57e1bdf00b2b73c80270c"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
// firebase-messaging.sw-merge.js
// Do not remove this separator.

importScripts("https://www.gstatic.com/firebasejs/8.4.1/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.4.1/firebase-messaging.js");

const firebaseConfig = {
    apiKey: "AIzaSyAWWgSyI7CxCdvZikY7rEgvMA-cFzPqpHc",
    authDomain: "timny-361806.firebaseapp.com",
    projectId: "timny-361806",
    storageBucket: "timny-361806.appspot.com",
    messagingSenderId: "5703412440",
    measurementId: "G-67ZME5LVDF",
    appId: "1:5703412440:web:85c0a74a14120a655bc5ad"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(message => {
    console.log('[firebase_messaging] Push message received');
    const notification = message.notification;

    if (notification.data) {
        clients.matchAll({
            type: 'window',
            includeUncontrolled: true
        }).then(clients => {
            if (!clients.length) {
                return;
            }

            clients.forEach(client => {
                client.postMessage({
                    'type': 'new_push_notification',
                    'data': notification.data
                });
            });
        });
    }
});
